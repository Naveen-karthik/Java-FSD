public class StringConversion {

    public static void main(String[] args) {
        // Create a String
        String str = "Hello, World!";
        System.out.println("Original String: " + str);

        // Convert String to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);
        System.out.println("StringBuffer: " + stringBuffer);

        // Convert String to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(str);
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
