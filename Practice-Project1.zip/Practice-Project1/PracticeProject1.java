// Implicit_Casting
public class PracticeProject1
{
	public static void main(String args[])
	{
	    byte i = 50;
	    // 
	    short j = i;
	    int k = j;
	    long l = k;
	    float m = l;
	    double n = m;
	System.out.println("     Implicit_casting");    
	    System.out.println("byte value : "+i);
	    System.out.println("short value : "+j);
	    System.out.println("int value : "+k);
	    System.out.println("long value : "+l);
	    System.out.println("float value : "+m);
	    System.out.println("double value : "+n);
        System.out.println(" ");
	
System.out.println("     Explicit_casting");

		double d = 75.0;
		// Explicit casting is needed for below conversion
		float f = (float) d;
		long o= (long) f;
		int g  = (int) l;
		short s = (short) i;
		byte b = (byte) s;
		
		System.out.println("double value : "+d);
		System.out.println("float value : "+f);
		System.out.println("long value : "+o);
		System.out.println("int value : "+g);
		System.out.println("short value : "+s);
		System.out.println("byte value : "+b);
	}
}