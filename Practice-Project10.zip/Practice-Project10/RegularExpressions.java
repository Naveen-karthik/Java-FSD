import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressions {

    public static void main(String[] args) {
        // Regular expression pattern to match email addresses
        String emailPattern = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";

        // Test strings
        String text1 = "Emails: john@example.com, alice@company.co, invalid_email";
        String text2 = "Phone numbers: 123-456-7890, (555) 555-5555, 9876543210";

        // Create a Pattern object
        Pattern pattern = Pattern.compile(emailPattern);

        // Match and extract email addresses from text1
        Matcher matcher1 = pattern.matcher(text1);
        System.out.println("Email addresses found in text1:");
        while (matcher1.find()) {
            System.out.println(matcher1.group());
        }

        // Replace phone numbers with "REDACTED" in text2
        String redactedText2 = text2.replaceAll("\\d{3}-\\d{3}-\\d{4}|\\(\\d{3}\\) \\d{3}-\\d{4}|\\d{10}", "REDACTED");
        System.out.println("\nRedacted text2:");
        System.out.println(redactedText2);
    }
}

