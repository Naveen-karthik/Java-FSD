import java.util.LinkedList;
import java.util.Queue;

public class Queue1 {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue elements into the queue
        queue.offer(1);
        queue.offer(2);
        queue.offer(3);
        queue.offer(4);
        queue.offer(5);

        System.out.println("Queue after enqueuing elements: " + queue);

        // Dequeue elements from the queue
        int dequeuedElement = queue.poll();
        System.out.println("Dequeued element: " + dequeuedElement);
        System.out.println("Queue after dequeuing an element: " + queue);

        // Peek at the front element without removing it
        int frontElement = queue.peek();
        System.out.println("Front element (peek): " + frontElement);
        System.out.println("Queue after peeking: " + queue);
    }
}

