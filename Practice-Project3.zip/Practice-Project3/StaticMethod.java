public class StaticMethod {

    // Method with no parameters and no return value (void)
    public static void greet() {
        System.out.println("Hello, World!");
    }

    // Method with parameters and a return value
    public static int add(int a, int b) {
        return a + b;
    }

    // Method with variable arguments (varargs)
    public static int sum(int... numbers) {
        int result = 0;
        for (int num : numbers) {
            result += num;
        }
        return result;
    }

    // Method overloading (two methods with the same name but different parameters)
    public static double add(double a, double b) {
        return a + b;
    }

    public static void main(String[] args) {
        // Calling the greet method
        greet();

        // Calling the add method with integers
        int sum1 = add(5, 3);
        System.out.println("Sum of integers: " + sum1);

        // Calling the sum method with varargs
        int sum2 = sum(1, 2, 3, 4, 5);
        System.out.println("Sum of varargs: " + sum2);

        // Calling the add method with doubles (method overloading)
        double sum3 = add(2.5, 3.7);
        System.out.println("Sum of doubles: " + sum3);
    }
}
