public class ConstructorTypes {

    // Default constructor (no parameters)
    public ConstructorTypes() {
        System.out.println("Default constructor called.");
    }

    // Parameterized constructor with one parameter
    public ConstructorTypes(String message) {
        System.out.println("Parameterized constructor with message: " + message);
    }

    // Overloaded constructor with two parameters
    public ConstructorTypes(int num1, int num2) {
        int sum = num1 + num2;
        System.out.println("Overloaded constructor with sum: " + sum);
    }

    public static void main(String[] args) {
        // Creating objects using different constructors
        ConstructorTypes obj1 = new ConstructorTypes(); // Calls the default constructor
        ConstructorTypes obj2 = new ConstructorTypes("Hello, World!"); // Calls the parameterized constructor with a message
        ConstructorTypes obj3 = new ConstructorTypes(5, 3); // Calls the overloaded constructor with numbers
    }
}
