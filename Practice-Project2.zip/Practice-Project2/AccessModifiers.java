//package com.example; // Define a package

// A class with different access modifiers
public class AccessModifiers {
    // Public field - accessible from anywhere
    public int publicField = 1;

    // Private field - accessible only within this class
    private int privateField = 2;

    // Protected field - accessible within this class, subclasses, and package
    protected int protectedField = 3;

    // Default (package-private) field - accessible within the same package
    int defaultField = 4;

    // Public constructor
    public AccessModifiers() {
        System.out.println("Public constructor");
    }

    // Private method - accessible only within this class
    private void privateMethod() {
        System.out.println("Private method");
    }

    // Protected method - accessible within this class, subclasses, and package
    protected void protectedMethod() {
        System.out.println("Protected method");
    }

    // Default (package-private) method - accessible within the same package
    void defaultMethod() {
        System.out.println("Default method");
    }

    // Public method - accessible from anywhere
    public void publicMethod() {
        System.out.println("Public method");
    }

    public static void main(String[] args) {
        AccessModifiers example = new AccessModifiers();

        // Accessing fields and methods from the same class
        System.out.println(example.publicField);
        System.out.println(example.privateField); // Error: privateField is private
        System.out.println(example.protectedField);
        System.out.println(example.defaultField);
        
        example.publicMethod();
        example.privateMethod(); // Error: privateMethod is private
        example.protectedMethod();
        example.defaultMethod();
    }
}
