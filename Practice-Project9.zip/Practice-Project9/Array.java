public class Array {

    public static void main(String[] args) {
        // Declaring and initializing an array of integers
        int[] numbers = { 1, 2, 3, 4, 5 };

        // Accessing and printing array elements
        System.out.print("Array elements: ");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();

        // Declaring an array of strings and initializing it later
        String[] fruits;
        fruits = new String[] { "Apple", "Banana", "Cherry" };

        // Accessing and printing array elements using an enhanced for loop
        System.out.print("Array elements (enhanced for loop): ");
        for (String fruit : fruits) {
            System.out.print(fruit + " ");
        }
        System.out.println();

        // Multi-dimensional array (2D array)
        int[][] matrix = {
            { 1, 2, 3 },
            { 4, 5, 6 },
            { 7, 8, 9 }
        };

        // Accessing and printing elements of a 2D array
        System.out.println("2D Array elements:");
        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[row].length; col++) {
                System.out.print(matrix[row][col] + " ");
            }
            System.out.println();
        }
    }
}
