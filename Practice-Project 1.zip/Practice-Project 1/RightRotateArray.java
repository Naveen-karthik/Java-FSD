public class RightRotateArray {
    public static void main(String[] args) {
        int[] originalArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int k = 5; // Number of steps to rotate

        int[] rotatedArray = rightRotate(originalArray, k);

        System.out.println("Original Array:");
        printArray(originalArray);

        System.out.println("\nArray after " + k + " right rotations:");
        printArray(rotatedArray);
    }

    public static int[] rightRotate(int[] arr, int k) {
        int n = arr.length;
        int[] rotatedArray = new int[n];

        for (int i = 0; i < n; i++) {
            // Calculate the new index after right rotation
            int newIndex = (i + k) % n;
            rotatedArray[newIndex] = arr[i];
        }

        return rotatedArray;
    }

    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
