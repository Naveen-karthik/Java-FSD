public class OuterClass {
    // Outer class members
    private int outerField = 10;
    private static int outerStaticField = 20;

    // Constructor for the outer class
    public OuterClass() {
        System.out.println("Outer class constructor");
    }

    // Inner class (non-static inner class or nested class)
    public class InnerClass {
        // Inner class members
        private int innerField = 5;

        // Constructor for the inner class
        public InnerClass() {
            System.out.println("Inner class constructor");
        }

        // Inner class method accessing outer class members
        public void display() {
            System.out.println("InnerField: " + innerField);
            System.out.println("OuterField: " + outerField);
            System.out.println("OuterStaticField: " + outerStaticField);
        }
    }

    public static void main(String[] args) {
        // Creating an instance of the outer class
        OuterClass outerObj = new OuterClass();

        // Creating an instance of the inner class using the outer class object
        InnerClass innerObj = outerObj.new InnerClass();

        // Accessing inner class members and methods
        innerObj.display();
    }
}

