import java.util.Arrays;
import java.util.Scanner;

public class ExponentialSearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of elements in the sorted array: ");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements of the sorted array in ascending order:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.print("Enter the element to search for: ");
        int searchElement = sc.nextInt();

        int result = exponentialSearch(arr, searchElement);

        if (result != -1) {
            System.out.println("Element found at index " + result);
        } else {
            System.out.println("Element not found in the array");
        }
    }

    // Exponential search function
    public static int exponentialSearch(int[] arr, int target) {
        if (arr[0] == target) {
            return 0; // Return the index 0 if the element is found at the first position
        }

        int i = 1;
        while (i < arr.length && arr[i] <= target) {
            i *= 2;
        }

        // Perform binary search within the found range
        int left = i / 2;
        int right = Math.min(i, arr.length - 1);
        return binarySearch(arr, target, left, right);
    }

    // Binary search function for a specific range
    public static int binarySearch(int[] arr, int target, int left, int right) {
        if (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid; // Return the index where the element is found
            } else if (arr[mid] < target) {
                return binarySearch(arr, target, mid + 1, right);
            } else {
                return binarySearch(arr, target, left, mid - 1);
            }
        }
        return -1; // Return -1 if the element is not found in the specified range
    }
}

