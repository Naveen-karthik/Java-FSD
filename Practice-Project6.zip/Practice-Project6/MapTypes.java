import java.util.HashMap;
import java.util.TreeMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Iterator;

public class MapTypes {

    public static void main(String[] args) {
        // HashMap Example
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Alice", 25);
        hashMap.put("Bob", 30);
        hashMap.put("Charlie", 22);
        System.out.println("HashMap: " + hashMap);

        // TreeMap Example (Sorts keys in natural order)
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Orange", 5);
        treeMap.put("Apple", 3);
        treeMap.put("Banana", 8);
        System.out.println("TreeMap: " + treeMap);

        // LinkedHashMap Example (Preserves insertion order)
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("One", 1);
        linkedHashMap.put("Three", 3);
        linkedHashMap.put("Two", 2);
        System.out.println("LinkedHashMap: " + linkedHashMap);

        // Iterating through a map
        System.out.print("Iterating through HashMap: ");
        for (String key : hashMap.keySet()) {
            System.out.print(key + ":" + hashMap.get(key) + " ");
        }
        System.out.println();

        // Iterating through a map using an Iterator
        System.out.print("Iterating through TreeMap using Iterator: ");
        Iterator<Map.Entry<String, Integer>> iterator = treeMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            System.out.print(entry.getKey() + ":" + entry.getValue() + " ");
        }
        System.out.println();
    }
}
