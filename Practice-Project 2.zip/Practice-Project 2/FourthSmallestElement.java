import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = {12, 3, 1, 15, 9, 20, 7};
        int fourthSmallest = findFourthSmallest(unsortedList);

        System.out.println("Fourth smallest element is: " + fourthSmallest);
    }

    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            throw new IllegalArgumentException("The array should contain at least 4 elements.");
        }

        // Sort the array in ascending order
        Arrays.sort(arr);

        // The fourth smallest element will be at index 3 (0-based index)
        return arr[3];
    }
}
