import java.util.*;

class Expense {
    private String date;
    private String description;
    private double amount;

    public Expense(String date, String description, double amount) {
        this.date = date;
        this.description = description;
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public double getAmount() {
        return amount;
    }
}

class BudgetTracker {
    private Map<String, List<Expense>> budgetData; // Using a Map for month-wise expenses

    public BudgetTracker() {
        budgetData = new HashMap<>();
    }

    public void addExpense(String month, Expense expense) {
        budgetData.computeIfAbsent(month, k -> new ArrayList<>()).add(expense);
    }

    public List<Expense> getExpensesByMonth(String month) {
        return budgetData.getOrDefault(month, new ArrayList<>());
    }

    public double getTotalExpensesByMonth(String month) {
        List<Expense> expenses = budgetData.getOrDefault(month, new ArrayList<>());
        double total = expenses.stream().mapToDouble(Expense::getAmount).sum();
        return total;
    }

    public void resetBudget(String month) {
        budgetData.remove(month);
    }

    public void deleteExpense(String month, int expenseIndex) {
        List<Expense> expenses = budgetData.getOrDefault(month, new ArrayList<>());
        if (expenseIndex >= 0 && expenseIndex < expenses.size()) {
            expenses.remove(expenseIndex);
        }
    }
}

public class BudgetTrackerApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BudgetTracker budgetTracker = new BudgetTracker();

        while (true) {
            System.out.println("\nBudget Tracker Application");
            System.out.println("1. Add Expense");
            System.out.println("2. View Expenses by Month");
            System.out.println("3. Get Total Expenses by Month");
            System.out.println("4. Reset Budget for a Month");
            System.out.println("5. Delete Expense");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter month (e.g., 'January 2023'): ");
                    String month = scanner.nextLine();
                    System.out.print("Enter date (e.g., '2023-01-15'): ");
                    String date = scanner.nextLine();
                    System.out.print("Enter expense description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter expense amount: ");
                    double amount = scanner.nextDouble();

                    Expense expense = new Expense(date, description, amount);
                    budgetTracker.addExpense(month, expense);
                    System.out.println("Expense added successfully.");
                    break;

                case 2:
                    System.out.print("Enter month to view expenses: ");
                    String viewMonth = scanner.nextLine();
                    List<Expense> expenses = budgetTracker.getExpensesByMonth(viewMonth);
                    if (!expenses.isEmpty()) {
                        System.out.println("Expenses for " + viewMonth + ":");
                        for (int i = 0; i < expenses.size(); i++) {
                            System.out.println((i + 1) + ". " + expenses.get(i).getDescription() + " - $"
                                    + expenses.get(i).getAmount());
                        }
                    } else {
                        System.out.println("No expenses for " + viewMonth);
                    }
                    break;

                case 3:
                    System.out.print("Enter month to calculate total expenses: ");
                    String totalMonth = scanner.nextLine();
                    double total = budgetTracker.getTotalExpensesByMonth(totalMonth);
                    System.out.println("Total expenses for " + totalMonth + ": $" + total);
                    break;

                case 4:
                    System.out.print("Enter month to reset the budget: ");
                    String resetMonth = scanner.nextLine();
                    budgetTracker.resetBudget(resetMonth);
                    System.out.println("Budget for " + resetMonth + " reset.");
                    break;

                case 5:
                    System.out.print("Enter month to delete expense: ");
                    String deleteMonth = scanner.nextLine();
                    System.out.print("Enter the index of the expense to delete: ");
                    int expenseIndex = scanner.nextInt();
                    budgetTracker.deleteExpense(deleteMonth, expenseIndex - 1);
                    System.out.println("Expense deleted.");
                    break;

                case 6:
                    System.out.println("Thank you for using the Budget Tracker Application. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
